
/*
 * d3 component, using the d3ComponentBase
 */

 var D3Component =  D3ComponentBase.extend({

    defaultWidth: 600,
    defaultHeight: 400

   });


