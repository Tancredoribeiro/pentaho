#Sparkl
===

Sparkl - Create and explore pentaho plugins.

[Sparkl HomePage](http://community.pentaho.com/projects/sparkl/)

Sparkl is a CPK (Comunity Plugin Kickstarter) plugin that allows you to easily build other CPK plugins. As such, you can take full advantage of all CPK features. To learn more about this please refer to the [CPK readme](https://github.com/webdetails/cpk/blob/master/README.md)
