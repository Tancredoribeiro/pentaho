wd = wd || {};
wd.helpers = wd.helpers || {};

wd.helpers.editor = {
    getUrl: function(){
        return "/plugin/pentaho-cdf-dd/api/editor/getExternalEditor?";
    }
}